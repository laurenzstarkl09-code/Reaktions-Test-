FARBENBLITZ – INSTALLIERBARE WEB-APP

INHALT
- index.html: das Reaktionsspiel
- manifest.webmanifest: App-Name, Symbol und Startmodus
- sw.js: Offline-Caching (Service Worker)
- icons/: App-Symbole

WICHTIG
Damit iPhone „Zum Home-Bildschirm“ die App als eigenständige Web-App installieren kann,
müssen diese Dateien über eine HTTPS-Adresse erreichbar sein. Eine lokale HTML-Datei
oder ein ChatGPT-Dateilink reicht dafür nicht aus.

EINFACHE VERÖFFENTLICHUNG ÜBER GITHUB PAGES
1. Melde dich bei github.com an und erstelle ein neues Repository, z.B. „farbenblitz“.
2. Lade ALLE Dateien und den Ordner „icons“ aus diesem Paket in das Repository hoch.
   Die Datei index.html muss direkt im Hauptordner liegen.
3. Öffne im Repository Settings -> Pages.
4. Wähle „Deploy from a branch“, Branch „main“, Ordner „/ (root)“, dann Save.
5. Nach der Veröffentlichung zeigt GitHub eine HTTPS-Adresse an, z.B.
   https://DEIN-NUTZERNAME.github.io/farbenblitz/
   (Die tatsächliche Adresse hängt von deinem GitHub-Namen ab.)

INSTALLATION AUF DEM IPHONE
1. Öffne die veröffentlichte HTTPS-Adresse in Safari.
2. Tippe auf „Teilen“.
3. Wähle „Zum Home-Bildschirm“ und dann „Hinzufügen“.
4. Öffne Farbenblitz über das neue Symbol.

Die App kann danach offline starten, sobald sie einmal online geladen wurde.
